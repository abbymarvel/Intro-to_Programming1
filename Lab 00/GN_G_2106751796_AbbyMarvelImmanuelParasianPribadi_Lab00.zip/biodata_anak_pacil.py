print("Biodata Anak Pacil 2021")

nama = input("Nama: ")
alamat = input("Alamat: ")
tanggal_lahir = input("Tanggal Lahir: ")
hobi = input("Hobi: ")
program_studi = input("Program Studi: ")

print()
print("Biodataku:")
print(nama)
print(tanggal_lahir)
print(hobi)
print(program_studi)
